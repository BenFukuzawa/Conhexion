// DO NOT MODIFY!!!


public interface Player
{
	// Returns the Location where this Player chooses to move
	Location getNextMove(Board board, int player);
}
